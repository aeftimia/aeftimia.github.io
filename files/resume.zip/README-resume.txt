# Resume source
`resume.tex` is the canonical source. Run `pdflatex resume.tex` to rebuild `resume.pdf`.
